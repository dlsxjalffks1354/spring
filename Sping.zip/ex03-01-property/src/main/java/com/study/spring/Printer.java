package com.study.spring;

public interface Printer
{ 
	public void print(String message);
}
