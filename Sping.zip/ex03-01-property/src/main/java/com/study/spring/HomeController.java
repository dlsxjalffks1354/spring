package com.study.spring;

public class HomeController {
	
	public static void main(String[] args)
	{
		System.out.println("aaaa");
	}
	
}
